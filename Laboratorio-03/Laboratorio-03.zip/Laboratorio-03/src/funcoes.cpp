#include <iostream>

using namespace std;

int nn;
int x, kk, y = 100, sum = 0, media = 0, i, hig = 0, low = 0; // na tarefa 3 kkkk = nn + 1 NÃO ESQUECER CARALHO
enum Operacoes { opMaxx = 1, opMinn, opSumm, opAvgg, opHigg, opLoww};

int opMax(int *vint, int nn, int valor){
	if (kk < nn){
		if (x < vint[kk]){
			x = vint[kk];
		}
		kk++;
		opMax(vint, nn, 0);
	}
	kk=0;
	return x;
}
int opMin(int *vint, int nn, int valor){
	if (kk < nn){
		if (y > vint[kk]){
			y = vint[kk];
		}
		kk++;
		opMin(vint, nn, 0);
	}
	kk=0;
	return y;
}
int opSum(int *vint, int nn, int valor){
	if (kk < nn){
		sum += vint[kk];
		kk++;
		opSum(vint, nn, 0);
	}
	kk=0;
	return sum;
}
int opAvg(int *vint, int nn, int valor){
	if (kk < nn){
		media += vint[kk];
		kk++;
		opAvg(vint, nn, 0);
	}
	kk=0;
	return (media/nn);
}
int opHig(int *vint, int nn, int valor){
	if (kk < nn){
		if (valor < vint[kk]){
		hig++;
		}
		kk++;
		opHig(vint, nn, valor);
	}
	kk=0;
	return hig;
}
int opLow(int *vint, int nn, int valor){
	if (kk < nn){
		if (valor > vint[kk]){
		low++;
		}
		kk++;
		opLow(vint, nn, valor);
	}
	kk=0;
	return low;
}
void ler_vetor(int nn, int *vint){
	if (i < nn){
		cout << "Digite o elemento " << i << endl;
		cin >> vint[i];
		i++;
		ler_vetor(nn, vint);
	}
}
int doVector (int* vetor, int tamanho, int valor, int (*funcao) (int*, int, int)){
	cout << funcao(vetor, tamanho, valor) << endl;
}


