/**
 * @file	main.cpp
 * @brief	Arquivo principal do programa que realiza operacoes sobre um vetor
 *			de diferentes tipos de dados
 * @author	Everton Cavalcante (everton@dimap.ufrn.br)
 * @author  Silvio Sampaio (silviocs@imd.ufrn.br)
 * @since	28/03/2017
 * @date	30/03/2017
 */

#include <iostream>
#include <string>
#include "funcoes.h"

using namespace std;

int *vint, tamanho;



//int* vint = NULL;			// Vetor de inteiros
/** @brief Funcao principal */

int main(){

	cout <<"Digite o tamanho do vetor" << endl;
	cin >> tamanho;

	vint = new int[tamanho];
	ler_vetor(tamanho, vint); //Le o vetor
	int (*ponteiroFuncao) (int*, int, int);
   	ponteiroFuncao = opMax;
   	doVector(vint, tamanho, 0, ponteiroFuncao);   	

	
	delete[] vint;
}


















