#ifndef FUNCOES_H
#define FUNCOES_H

enum Operacoes { opMaxx = 1, opMinn, opSumm, opAvgg, opHigg, opLoww};
int opMax(int *vint, int nn, int valor);
int opMin(int *vint, int nn, int valor);
int opSum(int *vint, int nn, int valor);
int opAvg(int *vint, int nn, int valor);
int opHig(int *vint, int nn, int valor);
int opLow(int *vint, int nn, int valor);
void ler_vetor(int tamanho, int *vint);
int doVector (int* vetor, int tamanho, int valor, int
 (*funcao) (int*, int, int));
//int doVector (int* vetor, int tamanho, int valor, int (*funcao) (int, int, int));

#endif