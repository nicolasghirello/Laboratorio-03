/**
 * @file	main.cpp
 * @brief	Arquivo principal do programa que realiza operacoes sobre um vetor
 *			de diferentes tipos de dados
 * @author	Everton Cavalcante (everton@dimap.ufrn.br)
 * @author  Silvio Sampaio (silviocs@imd.ufrn.br)
 * @since	28/03/2017
 * @date	30/03/2017
 */

// Realizar inclusao das respectivas bibliotecas

/** @brief Funcao principal */
int main() {
	
	string tipo_dados;				// Tipo de dados (int, float, double,
	cout << "Tipo de dados: ";
	cin >> tipo_dados;

	int tamanho;
	cout << "Informe a quantidade de elementos: ";
	cin >> tamanho;

	// Possiveis vetores a serem alocados dinamicamente conforme a necessidade
	int* vint = NULL;			// Vetor de inteiros
	float* vfloat = NULL;		// Vetor de decimais (float)
	double* vdouble = NULL;		// Vetor de decimais (double)
	string* vstring = NULL;		// Vetor de strings

	// Alocacao, preenchimento e impressao do vetor de acordo com o tipo
	if (tipo_dados == "int") {
		// Alocar dinamicamente o vetor de inteiros
		// Preencher o vetor chamando funcao genérica
		// Imprimir o vetor chamando funcao genérica
	} 

	// Executar as mesmas instrucoes para os demais tipos de dados

	// Apresentar opcoes de operacoes ao usuario

	int operacao = 0;     // Opcao de operacao a ser escolhida pelo usuario
   	cin >> operacao;   
	if (operacao != 0) {
		if (tipo_dados == "int") {
        	doVector(vint, tamanho, tipo_operacao(op), 0);
       	} else if (tipo_dados == "float") {
			doVector(vfloat, tamahho, tipo_operacao(op), 0);
       	} else if (tipo_dados == "double") {
           	doVector(vdouble, tamanho, tipo_operacao(op), 0);
       	} else {
           	doVector(vstring, tamanho, tipo_operacao(op), 0);
       	}
   	}

	cout << "Programa encerrado." << endl;
	return 0;
}
